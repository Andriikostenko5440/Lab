import json
from pathlib import Path
from user import User

class Storage:
    FILE_PATH = "users.json"

    def __init__(self):
        self.file = Path(self.FILE_PATH)
        if not self.file.exists():
            self.file.write_text("[]", encoding="utf-8")  

    def read_users(self):
        """Зчитуємо користувачів з файлу JSON."""
        with open(self.FILE_PATH, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []  

    def write_users(self, users):
        """Записуємо список користувачів у JSON-файл."""
        with open(self.FILE_PATH, "w", encoding="utf-8") as f:
            json.dump(users, f, indent=4, ensure_ascii=False)

    def add_user(self, user):
        """Додаємо нового користувача у файл JSON."""
        users = self.read_users()
        users.append(user.to_dict())  
        self.write_users(users)
        print(" Користувач успішно доданий!")

    def add_user_from_input(self):
        """Запитує дані у користувача та додає його у файл."""
        login = input("🔹 Введіть свій логін: ")
        fullname = input("🔹 Введіть повне ім'я: ")
        role = int(input("🔹 Роль (0 - користувач, 1 - адміністратор): "))
        year = int(input("🔹Введіть рік народження: "))

        user = User(login, fullname, role, year)  
        self.add_user(user)

    def get_all_users(self):
        """Повертає список користувачів у вигляді об'єктів User."""
        return [User.from_dict(user) for user in self.read_users()]

    def update_status(self, user_id, is_enabled):
        """Оновлює статус активності користувача."""
        users = self.read_users()
        for user in users:
            if user["id"] == user_id:
                user["is_enabled"] = is_enabled
                print(f"🔄 Статус користувача {user_id} оновлено на {is_enabled}")

        self.write_users(users)  
