from storage import Storage

storage = Storage()
storage.add_user_from_input()


print("\n Усі користувачі:")
for user in storage.get_all_users():
    print(f"{user.id} | {user.login} | {user.fullname} | {user.is_enabled}")