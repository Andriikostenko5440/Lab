from datetime import datetime
from uuid import uuid4

class User:
    def __init__(self, login, fullname, role=0, year=None, user_id=None, registered_at=None, is_enabled=True):
        self.id = user_id or str(uuid4())  
        self.login = login  
        self.fullname = fullname 
        self.role = role 
        self.year = year
        self.registered_at = registered_at or datetime.now().isoformat() 
        self.is_enabled = is_enabled 

    def to_dict(self):
        """Перетворює об'єкт у словник (для збереження у JSON)."""
        return {
            "id": self.id,
            "login": self.login, 
            "fullname": self.fullname,
            "role": self.role, 
            "year": self.year,
            "registration_date": self.registered_at,
            "is_enabled": self.is_enabled
        }

    @staticmethod
    def from_dict(data):
        """Створює об'єкт User із словника (зчитаного з JSON)."""
        return User(
            login=data["login"],
            fullname=data["fullname"],
            year=data["year"],
            role=data["role"],
            user_id=data["id"],  
            registered_at=data.get("registration_date"),  
            is_enabled=data.get("is_enabled", True)
        )
